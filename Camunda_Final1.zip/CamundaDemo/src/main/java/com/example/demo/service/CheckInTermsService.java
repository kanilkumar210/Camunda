package com.example.demo.service;

import java.util.Map;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.WayLeaves;
import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("checkInTerms") // create a subscription for this topic name
public class CheckInTermsService implements ExternalTaskHandler {

	@Autowired
	private WayLeavesRepository wayLeaveRepo;

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {

//		String grantorApproval = externalTask.getVariable("grantorApproval");
//
//		System.out.println(grantorApproval + " ------------------");
//
//		WayLeaves wayLeaveObj = wayLeaveRepo.findByProcessInstanceId(externalTask.getProcessInstanceId());
//
//		wayLeaveObj.setGranterApproval(grantorApproval);
//
//		wayLeaveRepo.save(wayLeaveObj);

		Map<String, Object> variables = externalTask.getAllVariables();

//		externalTaskService.complete(externalTask, variables);

		System.out.println("Inside Check In Terms ");

		externalTaskService.complete(externalTask, variables);

	}

}
