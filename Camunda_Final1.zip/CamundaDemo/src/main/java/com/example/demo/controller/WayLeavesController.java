package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.WayLeaves;
import com.example.demo.repository.WayLeavesRepository;

@Controller
public class WayLeavesController {

	@Autowired
	private WayLeavesRepository wayLeaveRepo;

	@GetMapping("/getWayLeavesById/{id}")
	public ResponseEntity<String> getWayLeavesById(@PathVariable("id") Long id) {
		return new ResponseEntity<String>(wayLeaveRepo.findById(id).get().getProcessInstanceId(), HttpStatus.OK);
	}

	@PutMapping("/wayLeaveValidation/{number}")
	public WayLeaves getWayLeavesInstanceId(@PathVariable("number") Long number,
			@RequestParam("approval") String approval) {

		WayLeaves wayLeave = wayLeaveRepo.findById(number).get();

		WayLeaves wayLeaveObj = wayLeaveRepo.findByProcessInstanceId(wayLeave.getProcessInstanceId());

		if (approval.equalsIgnoreCase("Yes") || approval.equalsIgnoreCase("No")) {
			wayLeaveObj.setHandlerApproval(approval);
			return wayLeaveRepo.save(wayLeaveObj);

		} else if (approval.equalsIgnoreCase("Accepted") || approval.equalsIgnoreCase("Rejected")
				|| approval.equalsIgnoreCase("checkinterms")) {
			wayLeaveObj.setGranterApproval(approval);
			return wayLeaveRepo.save(wayLeaveObj);
		}

		return wayLeaveObj;

	}

}
