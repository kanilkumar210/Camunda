package com.example.demo.service;

import java.util.Map;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("handlerIssue") // create a subscription for this topic name
public class HandlerIssueService implements ExternalTaskHandler {

	@Autowired
	private WayLeavesRepository wayleavesRepo;

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {

//		String handlerApproval = externalTask.getVariable("handlerApproval");
//
//		String processInstanceId = externalTask.getProcessInstanceId();
//
//		WayLeaves wayLeaveObj = wayleavesRepo.findByProcessInstanceId(processInstanceId);
//
//		wayLeaveObj.setHandlerApproval(handlerApproval);
//		wayleavesRepo.save(wayLeaveObj);
//
//		System.out.println(handlerApproval + " ------------------");

		Map<String, Object> variables = externalTask.getAllVariables();

		System.out.println("Inside Handler Issue");

		externalTaskService.complete(externalTask, variables);

	}

}
