package com.example.demo.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class WayLeaves {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long number;

	private String processInstanceId;

	private String isPayable;
	private String paymentStatus;

	private String comment;

	private Date createdDate;

	private String handlerApproval;

	private String granterApproval;

	@ManyToOne(fetch = FetchType.LAZY, targetEntity = Handler.class)
	@JoinColumn(name = "handler_id")
	private Handler handler;

//	
//	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
//	@JoinColumn(name="address_id")
//	private Address address;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "grantor_id")
	private Grantor grantor;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "appratus_id")
	private Apparatus apparatus;

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public String getHandlerApproval() {
		return handlerApproval;
	}

	public void setHandlerApproval(String handlerApproval) {
		this.handlerApproval = handlerApproval;
	}

	public WayLeaves(Long number, String isPayable, String paymentStatus, String comment, Date createdDate,
			String handlerApproval, String granterApproval, Handler handler, Grantor grantor, Apparatus apparatus) {
		super();
		this.number = number;
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.createdDate = createdDate;
		this.handlerApproval = handlerApproval;
		this.granterApproval = granterApproval;
		this.handler = handler;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public WayLeaves(Long number, String isPayable, String paymentStatus, String comment, Date createdDate,
			String granterApproval, Handler handler, Grantor grantor, Apparatus apparatus) {
		super();
		this.number = number;
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.createdDate = createdDate;
		this.granterApproval = granterApproval;
		this.handler = handler;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public String getIsPayable() {
		return isPayable;
	}

	public void setIsPayable(String isPayable) {
		this.isPayable = isPayable;
	}

	public WayLeaves(Long number, String isPayable, String paymentStatus, String comment, Date createdDate,
			String granterApproval, Grantor grantor, Apparatus apparatus) {
		super();
		this.number = number;
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.createdDate = createdDate;
		this.granterApproval = granterApproval;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public String getGranterApproval() {
		return granterApproval;
	}

	public void setGranterApproval(String granterApproval) {
		this.granterApproval = granterApproval;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public WayLeaves(Long number, String isPayable, String paymentStatus, String comment, Date createdDate,
			Grantor grantor, Apparatus apparatus) {
		super();
		this.number = number;
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.createdDate = createdDate;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public String isPayable() {
		return isPayable;
	}

	public void setPayable(String isPayable) {
		this.isPayable = isPayable;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Grantor getGranter() {
		return grantor;
	}

	public void setGranter(Grantor grantor) {
		this.grantor = grantor;
	}

//	public Address getAddress() {
//		return address;
//	}
//
//	public void setAddress(Address address) {
//		this.address = address;
//	}

	public WayLeaves() {
		super();
	}

	public WayLeaves(Long number, String isPayable, String paymentStatus, String comment, Grantor grantor,
			Apparatus apparatus) {
		super();
		this.number = number;
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public WayLeaves(String isPayable, String paymentStatus, String comment, Grantor grantor, Apparatus apparatus) {
		super();
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public Grantor getGrantor() {
		return grantor;
	}

	public void setGrantor(Grantor grantor) {
		this.grantor = grantor;
	}

	public Apparatus getApparatus() {
		return apparatus;
	}

	public void setApparatus(Apparatus apparatus) {
		this.apparatus = apparatus;
	}

	public WayLeaves(String isPayable, String paymentStatus, String comment, Date createdDate, String handlerApproval,
			String granterApproval, Handler handler, Grantor grantor, Apparatus apparatus) {
		super();
		this.isPayable = isPayable;
		this.paymentStatus = paymentStatus;
		this.comment = comment;
		this.createdDate = createdDate;
		this.handlerApproval = handlerApproval;
		this.granterApproval = granterApproval;
		this.handler = handler;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.processInstanceId + "  " + this.isPayable + " " + this.comment + " " + this.paymentStatus + " "
				+ this.apparatus + " " + this.grantor;
	}
}
