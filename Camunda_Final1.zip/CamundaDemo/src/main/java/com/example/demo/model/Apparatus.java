package com.example.demo.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class Apparatus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long appNumber;

	private String latitude;
	private String longitude;
	private String count;
	private String type;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Address address;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "apparatus")
	// @JoinTable(name = "wayLeaveId", joinColumns = @JoinColumn(name =
	// "app_number"), inverseJoinColumns = @JoinColumn(name = "number"))
	private WayLeaves wayleaves;

	private String status;

	public Long getNumber() {
		return appNumber;
	}

	public Long getAppNumber() {
		return appNumber;
	}

	public void setAppNumber(Long appNumber) {
		this.appNumber = appNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public WayLeaves getWayleaves() {
		return wayleaves;
	}

	public void setWayleaves(WayLeaves wayleaves) {
		this.wayleaves = wayleaves;
	}

	public Apparatus(Long appNumber, String latitude, String longitude, String count, String type, Address address,
			WayLeaves wayleaves, String status) {
		super();
		this.appNumber = appNumber;
		this.latitude = latitude;
		this.longitude = longitude;
		this.count = count;
		this.type = type;
		this.address = address;
		this.wayleaves = wayleaves;
		this.status = status;
	}

	public Apparatus(String latitude, String longitude, String count, String type, Address address) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
		this.count = count;
		this.type = type;
		this.address = address;
	}

	public void setNumber(Long number) {
		this.appNumber = number;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Apparatus(Long number, String latitude, String longitude, String count, String type, String status) {
		super();
		this.appNumber = number;
		this.latitude = latitude;
		this.longitude = longitude;
		this.count = count;
		this.type = type;
		this.status = status;
	}

	public Apparatus() {
		super();
	}

	public Apparatus(String latitude, String longitude, String count, String type, Address address, String status) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
		this.count = count;
		this.type = type;
		this.address = address;
		this.status = status;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.latitude + " " + this.longitude + " " + this.count + " " + this.status + " " + this.type;
	}

}
