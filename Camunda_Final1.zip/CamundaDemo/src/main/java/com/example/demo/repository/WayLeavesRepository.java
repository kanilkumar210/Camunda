package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.WayLeaves;

@Repository
public interface WayLeavesRepository extends JpaRepository<WayLeaves, Long> {

	@Query(value = "SELECT * FROM way_leaves  WHERE process_instance_id = ?1", nativeQuery = true)
	public WayLeaves findByProcessInstanceId(String processId);

	@Query(value = "select count(w.handler_id) as count,w.handler_id from way_leaves w inner join handler h where w.handler_id=h.handler_id and h.region=?1 group by w.handler_id order by count asc limit 1", nativeQuery = true)
	public String findHandlerUsingCountWayLeaves(String region);

}
