package com.example.demo.service;

import java.util.Date;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.Address;
import com.example.demo.model.Apparatus;
import com.example.demo.model.Grantor;
import com.example.demo.model.WayLeaves;
import com.example.demo.repository.AddressRepository;
import com.example.demo.repository.HandlerRepository;
import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("testFlow") // create a subscription for this topic name
public class TestService implements ExternalTaskHandler {

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private HandlerRepository handlerRepo;

	@Autowired
	private WayLeavesRepository wayleavesRepo;

	private WayLeaves wayLeaveObj = new WayLeaves();

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
		// get variables

		// wayleaves variables
		String isPayable = externalTask.getVariable("isPayable");
		String paymentStatus = externalTask.getVariable("paymentStatus");
		String comment = externalTask.getVariable("comment");

		// apparatus variables
		String latitude = externalTask.getVariable("latitude");
		String longitude = externalTask.getVariable("longitude");
		String count = externalTask.getVariable("count");
		String type = externalTask.getVariable("type");
		String status = externalTask.getVariable("status");

		// grantor variables
		String title = externalTask.getVariable("title");
		String lastName = externalTask.getVariable("lastName");
		String firstName = externalTask.getVariable("firstName");
		String region = externalTask.getVariable("region");
		String primaryContact = externalTask.getVariable("primaryContact");
		String secondaryContact = externalTask.getVariable("secondaryContact");
		String email = externalTask.getVariable("email");

		// address variables
		String address1 = externalTask.getVariable("address1");
		String address2 = externalTask.getVariable("address2");
		String city = externalTask.getVariable("city");
		String country = externalTask.getVariable("country");
		String postCode = externalTask.getVariable("postCode");

		VariableMap variables = Variables.createVariables();
		variables.put("isPayable", isPayable);
		variables.put("comment", comment);
		variables.put("paymentStatus", paymentStatus);
		variables.put("latitude", latitude);
		variables.put("longitude", longitude);
		variables.put("count", count);
		variables.put("type", type);
		variables.put("status", status);
		variables.put("title", title);
		variables.put("lastName", lastName);
		variables.put("firstName", firstName);
		variables.put("region", region);
		variables.put("primaryContact", primaryContact);
		variables.put("secondaryContact", secondaryContact);
		variables.put("email", email);
		variables.put("address1", address1);
		variables.put("address2", address2);
		variables.put("city", city);
		variables.put("country", country);
		variables.put("postCode", postCode);
//		variables.put("handlerApproval", null);
//		variables.put("grantorApproval", null);

		Address address = new Address(address1, address2, city, country, postCode);
		System.out.println(address + " Address__________________________________");

		Grantor grantor = new Grantor(title, lastName, firstName, address, region, primaryContact, secondaryContact,
				email);

		System.out.println(grantor + "-------------------------------------------");

		Apparatus apparatus = new Apparatus(latitude, longitude, count, type, address, status);

		System.out.println(apparatus + "---------------------------------------");

		WayLeaves wayLeavesObj = new WayLeaves();
		wayLeavesObj.setApparatus(apparatus);
		wayLeavesObj.setComment(comment);
		wayLeavesObj.setCreatedDate(new Date());
		wayLeavesObj.setGranter(grantor);
		wayLeavesObj.setGranterApproval("Pending");
		wayLeavesObj.setHandlerApproval("Pending");
		wayLeavesObj.setIsPayable(isPayable);
		wayLeavesObj.setPaymentStatus(paymentStatus);
		wayLeavesObj.setProcessInstanceId(externalTask.getProcessInstanceId());

		System.out.println(wayLeavesObj + "   before saving testservice");

		this.wayleavesRepo.save(wayLeavesObj);

		externalTaskService.complete(externalTask, variables);

	}
}