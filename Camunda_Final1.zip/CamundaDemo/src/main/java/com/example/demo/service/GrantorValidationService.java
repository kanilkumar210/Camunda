package com.example.demo.service;

import java.util.Map;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.WayLeaves;
import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("grantorValidation") // create a subscription for this topic name
public class GrantorValidationService implements ExternalTaskHandler {

	@Autowired
	private WayLeavesRepository wayleavesRepo;

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {

		String handlerApproval = externalTask.getVariable("handlerApproval");

		System.out.println(handlerApproval + "------------------------");

		// String grantorApproval = externalTask.getVariable("grantorApproval");

		WayLeaves wayLeaveObj = wayleavesRepo.findByProcessInstanceId(externalTask.getProcessInstanceId());

		Map<String, Object> variables = externalTask.getAllVariables();

		System.out.println("Inside Granter Validation ");

		if (wayLeaveObj.getGranterApproval().equalsIgnoreCase("Accepted")
				|| wayLeaveObj.getGranterApproval().equalsIgnoreCase("Rejected")
				|| wayLeaveObj.getGranterApproval().equalsIgnoreCase("checkinterms")) {
			variables.put("grantorApproval", wayLeaveObj.getGranterApproval());
			externalTaskService.complete(externalTask, variables);
		}

	}

}
