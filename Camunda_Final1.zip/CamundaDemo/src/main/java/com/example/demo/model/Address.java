package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long addNumber;
	private String address1;
	private String address2;
	@Column(name = "region")
	private String city;
	private String country;
	private String postCode;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "address")
//	@JoinTable(name = "grantorId", joinColumns = @JoinColumn(name = "add_number"), inverseJoinColumns = @JoinColumn(name = "grant_number"))
	private Grantor grantor;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "address")
//	@JoinTable(name = "grantorId", joinColumns = @JoinColumn(name = "add_number"), inverseJoinColumns = @JoinColumn(name = "grant_number"))
	private Apparatus apparatus;

//	@OneToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL,mappedBy = "address")
////	@JoinTable(name = "wayLeaveId", joinColumns = @JoinColumn(name = "add_number"), inverseJoinColumns = @JoinColumn(name = "number"))
//	private WayLeaves wayleaves;

	public Address(Long addNumber, String address1, String address2, String city, String country, String postCode,
			Grantor grantor, Apparatus apparatus) {
		super();
		this.addNumber = addNumber;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.country = country;
		this.postCode = postCode;
		this.grantor = grantor;
		this.apparatus = apparatus;
	}

	public Grantor getGrantor() {
		return grantor;
	}

	public Address(Long addNumber, String address1, String address2, String city, String country, String postCode) {
		super();
		this.addNumber = addNumber;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.country = country;
		this.postCode = postCode;
	}

	public void setGrantor(Grantor grantor) {
		this.grantor = grantor;
	}

	public Apparatus getApparatus() {
		return apparatus;
	}

	public void setApparatus(Apparatus apparatus) {
		this.apparatus = apparatus;
	}

	public Address(String address1, String address2, String city, String country, String postCode,
			boolean sameAsGranterAddress) {
		super();
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.country = country;
		this.postCode = postCode;
	}

	public Address(String address1, String address2, String city, String country, String postCode) {
		super();
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.country = country;
		this.postCode = postCode;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public Address() {
		super();
	}

	public Long getAddNumber() {
		return addNumber;
	}

	public void setAddNumber(Long addNumber) {
		this.addNumber = addNumber;
	}

	public Address(Long addNumber, String address1, String address2, String city, String country, String postCode,
			boolean sameAsGranterAddress) {
		super();
		this.addNumber = addNumber;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.country = country;
		this.postCode = postCode;
	}  

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.address1 + " " + this.address2 + " " + this.city + " " + this.country + " " + this.postCode;
	}

}
