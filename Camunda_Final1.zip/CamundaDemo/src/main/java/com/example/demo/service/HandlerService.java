package com.example.demo.service;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.Handler;
import com.example.demo.model.WayLeaves;
import com.example.demo.repository.HandlerRepository;
import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("updateHandler") // create a subscription for this topic name
public class HandlerService implements ExternalTaskHandler {

	@Autowired
	private WayLeavesRepository wayleaveRepo;

	@Autowired
	private HandlerRepository handlerRepo;

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {

//		String region = externalTask.getVariable("city");

		// wayleaves variables
		String isPayable = externalTask.getVariable("isPayable");
		String paymentStatus = externalTask.getVariable("paymentStatus");
		String comment = externalTask.getVariable("comment");

		// apparatus variables
		String latitude = externalTask.getVariable("latitude");
		String longitude = externalTask.getVariable("longitude");
		String count = externalTask.getVariable("count");
		String type = externalTask.getVariable("type");
		String status = externalTask.getVariable("status");

		// grantor variables
		String title = externalTask.getVariable("title");
		String lastName = externalTask.getVariable("lastName");
		String firstName = externalTask.getVariable("firstName");
		String region = externalTask.getVariable("region");
		String primaryContact = externalTask.getVariable("primaryContact");
		String secondaryContact = externalTask.getVariable("secondaryContact");
		String email = externalTask.getVariable("email");

		// address variables
		String address1 = externalTask.getVariable("address1");
		String address2 = externalTask.getVariable("address2");
		String city = externalTask.getVariable("city");
		String country = externalTask.getVariable("country");
		String postCode = externalTask.getVariable("postCode");

		VariableMap variables = Variables.createVariables();
		variables.put("isPayable", isPayable);
		variables.put("comment", comment);
		variables.put("paymentStatus", paymentStatus);
		variables.put("latitude", latitude);
		variables.put("longitude", longitude);
		variables.put("count", count);
		variables.put("type", type);
		variables.put("status", status);
		variables.put("title", title);
		variables.put("lastName", lastName);
		variables.put("firstName", firstName);
		variables.put("region", region);
		variables.put("primaryContact", primaryContact);
		variables.put("secondaryContact", secondaryContact);
		variables.put("email", email);
		variables.put("address1", address1);
		variables.put("address2", address2);
		variables.put("city", city);
		variables.put("country", country);
		variables.put("postCode", postCode);

		String handler = wayleaveRepo.findHandlerUsingCountWayLeaves(city);

		String handlerId = handler.split(",")[1];

		Handler handlerObj = handlerRepo.findById(Long.parseLong(handlerId)).get();

		System.out.println(handlerObj.getRegion() + "         handlerObj");

		WayLeaves wayLeaveObj = wayleaveRepo.findByProcessInstanceId(externalTask.getProcessInstanceId());
		wayLeaveObj.setHandler(handlerObj);

		System.out.println("before saving in handler service");

		wayleaveRepo.save(wayLeaveObj);

		externalTaskService.complete(externalTask, variables);

	}
}