package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Grantor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long GrantNumber;
	private String title;
	private String lastName;
	private String firstName;
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Address address;

	private String region;

	private String primaryContact;

	private String secondaryContact;

	private String email;

	public Long getGrantNumber() {
		return GrantNumber;
	}

	public void setGrantNumber(Long grantNumber) {
		GrantNumber = grantNumber;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public WayLeaves getWayleaves() {
		return wayleaves;
	}

	public void setWayleaves(WayLeaves wayleaves) {
		this.wayleaves = wayleaves;
	}

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "grantor")
//	@JoinTable(name = "wayLeaveId", joinColumns = @JoinColumn(name = "grant_number"), inverseJoinColumns = @JoinColumn(name = "number"))
	private WayLeaves wayleaves;

	public Long getNumber() {
		return GrantNumber;
	}

	public void setNumber(Long GrantNumber) {
		this.GrantNumber = GrantNumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPrimaryContact() {
		return primaryContact;
	}

	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}

	public String getSecondaryContact() {
		return secondaryContact;
	}

	public void setSecondaryContact(String secondaryContact) {
		this.secondaryContact = secondaryContact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Grantor() {
		super();
	}

	public Grantor(Long grantNumber, String title, String lastName, String firstName, Address address, String region,
			String primaryContact, String secondaryContact, String email, WayLeaves wayleaves) {
		super();
		GrantNumber = grantNumber;
		this.title = title;
		this.lastName = lastName;
		this.firstName = firstName;
		this.address = address;
		this.region = region;
		this.primaryContact = primaryContact;
		this.secondaryContact = secondaryContact;
		this.email = email;
		this.wayleaves = wayleaves;
	}
	
	

	public Grantor(String title, String lastName, String firstName, Address address, String region,
			String primaryContact, String secondaryContact, String email) {
		super();
		this.title = title;
		this.lastName = lastName;
		this.firstName = firstName;
		this.address = address;
		this.region = region;
		this.primaryContact = primaryContact;
		this.secondaryContact = secondaryContact;
		this.email = email;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.email + " " + this.firstName + " " + this.lastName + " " + this.primaryContact + " " + this.region
				+ " " + this.secondaryContact;
	}

}
