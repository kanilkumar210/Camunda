package com.example.demo.model;

public class WayLeavesApproval {

	private Long wayLeavesId;

	private String approvalStatus;

	public Long getWayLeavesId() {
		return wayLeavesId;
	}

	public void setWayLeavesId(Long wayLeavesId) {
		this.wayLeavesId = wayLeavesId;
	}

	public WayLeavesApproval(Long wayLeavesId, String approvalStatus) {
		super();
		this.wayLeavesId = wayLeavesId;
		this.approvalStatus = approvalStatus;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

}
