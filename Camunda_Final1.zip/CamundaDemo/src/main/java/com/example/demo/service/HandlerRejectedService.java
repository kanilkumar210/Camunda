//package com.example.demo.service;
//
//import java.util.Map;
//
//import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
//import org.camunda.bpm.client.task.ExternalTask;
//import org.camunda.bpm.client.task.ExternalTaskHandler;
//import org.camunda.bpm.client.task.ExternalTaskService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.example.demo.model.WayLeaves;
//import com.example.demo.repository.WayLeavesRepository;
//
//@Component
//@ExternalTaskSubscription("handlerRejected") // create a subscription for this topic name
//public class HandlerRejectedService implements ExternalTaskHandler {
//
//	@Autowired
//	private WayLeavesRepository wayLeaveRepo;
//
//	@Override
//	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {
//
//		String handlerApproval = externalTask.getVariable("handlerApproval");
//
//		System.out.println(handlerApproval + " ------------------");
//
//		WayLeaves wayLeaveObj = wayLeaveRepo.findByProcessInstanceId(externalTask.getProcessInstanceId());
//
//		
//		
//		
//		wayLeaveObj.setHandlerApproval(handlerApproval);
//
//		wayLeaveRepo.save(wayLeaveObj);
//
//		Map<String, Object> variables = externalTask.getAllVariables();
//		
//		if(wayLeaveObj)
//
//		externalTaskService.complete(externalTask, variables);
//
//		System.out.println("Rejected Successfully");
//
//	}
//
//}
