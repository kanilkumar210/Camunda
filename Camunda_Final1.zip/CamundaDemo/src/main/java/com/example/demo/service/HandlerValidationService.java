package com.example.demo.service;

import java.util.Map;

import org.camunda.bpm.client.spring.annotation.ExternalTaskSubscription;
import org.camunda.bpm.client.task.ExternalTask;
import org.camunda.bpm.client.task.ExternalTaskHandler;
import org.camunda.bpm.client.task.ExternalTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.WayLeaves;
import com.example.demo.repository.AddressRepository;
import com.example.demo.repository.HandlerRepository;
import com.example.demo.repository.WayLeavesRepository;

@Component
@ExternalTaskSubscription("handlerValidation") // create a subscription for this topic name
public class HandlerValidationService implements ExternalTaskHandler {

	@Autowired
	private AddressRepository addressRepo;

	@Autowired
	private HandlerRepository handlerRepo;

	@Autowired
	private WayLeavesRepository wayleavesRepo;

	@Override
	public void execute(ExternalTask externalTask, ExternalTaskService externalTaskService) {

		// String handlerApproval = externalTask.getVariable("handlerApproval");

		String processInstanceId = externalTask.getProcessInstanceId();

		WayLeaves wayLeaveObj = wayleavesRepo.findByProcessInstanceId(processInstanceId);

		System.out.println("Before saving in handler validation");

		Map<String, Object> variables = externalTask.getAllVariables();

		if (wayLeaveObj.getHandlerApproval().equalsIgnoreCase("Yes")
				|| wayLeaveObj.getHandlerApproval().equalsIgnoreCase("No")) {
			
			variables.put("handlerApproval", wayLeaveObj.getHandlerApproval());
			externalTaskService.complete(externalTask, variables);
		}

	}

}
