package com.example.demo.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Handler {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long handlerId;

	private String name;

	private String country;

	private String email;

	private String region;

	private String role;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "handler", targetEntity = WayLeaves.class)
	private List<WayLeaves> wayLeaves;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getHandlerId() {
		return handlerId;
	}

	public void setHandlerId(long handlerId) {
		this.handlerId = handlerId;
	}

	public List<WayLeaves> getWayLeaves() {
		return wayLeaves;
	}

	public void setWayLeaves(List<WayLeaves> wayLeaves) {
		this.wayLeaves = wayLeaves;
	}

	public Handler(long handlerId, String name, String country, String email, String region, String role,
			List<WayLeaves> wayLeaves) {
		super();
		this.handlerId = handlerId;
		this.name = name;
		this.country = country;
		this.email = email;
		this.region = region;
		this.role = role;
		this.wayLeaves = wayLeaves;
	}

	public Handler() {
		super();
	}

}
